package main

import (
	"encoding/json"
	"os"
	"os/exec"
	"path/filepath"
	"scenery.sh/internal/build"
	"strings"
)

func main() {
	root, _ := os.Getwd()
	base := filepath.Join(root, ".scenery/harness/direct-executable-retention")
	source, e := build.FrameworkSourceManifest(root)
	if e != nil {
		panic(e)
	}
	flags, e := build.FrameworkProducerLinkerFlags(source.Digest)
	if e != nil {
		panic(e)
	}
	mainPath := filepath.Join(root, "cmd/scenery/main.go")
	b, e := os.ReadFile(mainPath)
	if e != nil {
		panic(e)
	}
	newMain := filepath.Join(base, "main-overlay.go")
	os.WriteFile(newMain, []byte(strings.Replace(string(b), "func main() {", "func originalProductMain() {", 1)), 0600)
	data, _ := json.Marshal(map[string]any{"Replace": map[string]string{mainPath: newMain, filepath.Join(root, "cmd/scenery/direct_retention_driver.go"): filepath.Join(base, "driver.go")}})
	overlay := filepath.Join(base, "overlay.json")
	os.WriteFile(overlay, data, 0600)
	cmd := exec.Command("go", "build", "-overlay", overlay, "-ldflags="+flags, "-o", filepath.Join(base, "driver"), "./cmd/scenery")
	cmd.Stdout, cmd.Stderr = os.Stdout, os.Stderr
	if e = cmd.Run(); e != nil {
		panic(e)
	}
	data, _ = json.MarshalIndent(source, "", "  ")
	os.WriteFile(filepath.Join(base, "producer-source.json"), data, 0600)
}
