package main

import (
	"context"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io"
	"net"
	"net/http"
	"os"
	"path/filepath"
	localagent "scenery.sh/internal/agent"
	"scenery.sh/internal/app"
	"scenery.sh/internal/build"
	"scenery.sh/internal/compiler"
	"scenery.sh/internal/devcache"
	"sync"
	"time"
)

func main() {
	if err := auditDirect(); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
func auditDirect() error {
	rootArg := flag.String("app-root", "", "owned fixture")
	outArg := flag.String("output", "", "owned store")
	direct := flag.Bool("direct", false, "direct retention arm")
	flag.Parse()
	root, cfg, err := app.DiscoverRoot(*rootArg)
	if err != nil {
		return err
	}
	out, err := filepath.Abs(*outArg)
	if err != nil {
		return err
	}
	if err = os.MkdirAll(out, 0700); err != nil {
		return err
	}
	restore := devcache.SetRoot(filepath.Join(out, "cache"))
	defer restore()
	wireBuildGenerateHooks()
	var owner *build.ExecutableOwner
	if *direct {
		owner, err = build.OpenExecutableOwner(filepath.Join(out, "executables"), root)
		if err != nil {
			return err
		}
		defer owner.Close()
	}
	listener, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		return err
	}
	addr := listener.Addr().String()
	listener.Close()
	s := &devSupervisor{root: root, cfg: cfg, env: app.ResolvedEnv{Name: "test"}, addr: addr, backend: devBackend{Network: "tcp", Addr: addr}, agentSession: &localagent.Session{StateRoot: filepath.Join(out, "session")}, victoriaDesiredEnv: []string{}}
	defer func() {
		if a := s.detachCurrentApp(); a != nil {
			if a.stop() == nil {
				s.releaseUnusedAppBinary(a.launch)
			}
		}
	}()
	decoder, encoder := json.NewDecoder(os.Stdin), json.NewEncoder(os.Stdout)
	var baseline fileSnapshot
	for {
		var req struct {
			Label, Token string
			Unchanged    bool
 Proof bool
		}
		if e := decoder.Decode(&req); errors.Is(e, io.EOF) {
			return nil
		} else if e != nil {
			return e
		}
		start := time.Now()
		var captured fileSnapshot
		if baseline.files == nil {
			captured, err = scanInitialWatchedFiles(root, compiler.Compile)
		} else {
			captured, err = scanWatchedFilesReusing(root, baseline)
		}
		if err != nil {
			return err
		}
		capturedAt := time.Now()
		var mu sync.Mutex
		var steps []build.Step
		ctx := build.WithTrace(context.Background(), func(step build.Step) { mu.Lock(); steps = append(steps, step); mu.Unlock() })
		if owner != nil {
			ctx = build.WithExecutableOwner(ctx, owner)
		}
		phase := func(name string, fn func() error) error {
			t := time.Now()
			e := fn()
			mu.Lock()
			steps = append(steps, build.Step{Name: name, StartedAt: t, Duration: time.Since(t), OK: e == nil})
			mu.Unlock()
			return e
		}
		var p *devBuildPreparation
		var plan *appStartPlan
		var artifactMS float64
		var response map[string]any
		var responseAt time.Time
		err = func() error {
			if e := phase("audit.framework", func() error { return build.VerifyFrameworkSession(ctx, root) }); e != nil {
				return e
			}
			if e := phase("audit.graph", func() error { var e error; p, e = loadDevBuildPreparation(ctx, root, cfg, captured); return e }); e != nil {
				return e
			}
			defer func() {
				if p != nil && p.result != nil {
					_ = p.result.ReleaseExecutable()
				}
			}()
			if e := phase("audit.prepare", func() error { return p.prepare(ctx) }); e != nil {
				return e
			}
			if e := phase("audit.analyze", p.analyze); e != nil {
				return e
			}
			if e := phase("audit.compile_admission", func() error { return p.compile(ctx, build.CompileContext) }); e != nil {
				return e
			}
			if e := phase("audit.retain", func() error {
				var e error
				plan, e = s.prepareAppStart(ctx, p.result, p.metadata, p.apiEncoding, &devRuntimeEnvironment{base: os.Environ(), managed: os.Environ()})
				if plan != nil {
					plan.request.Stdout = os.Stderr
					plan.request.Stderr = os.Stderr
					plan.request.OnOutput = nil
				}
				return e
			}); e != nil {
				return e
			}
			defer s.releaseUnusedAppBinary(plan)
			artifactMS = float64(time.Since(capturedAt)) / float64(time.Millisecond)
			if e := phase("audit.preflight", func() error { return preflightAppStart(ctx, plan) }); e != nil {
				return e
			}
			if e := phase("audit.handoff", func() error {
				previous := s.detachCurrentApp()
				current, _, e := replaceAppGeneration(ctx, previous, plan, func(a *runningApp) error { return a.stop() }, s.startPreparedApp)
				s.mu.Lock()
				s.current = current
				s.mu.Unlock()
				if e == nil && previous != nil {
					s.releaseUnusedAppBinary(previous.launch)
				}
				return e
			}); e != nil {
				return e
			}
			// Release preparation reference and old executable before response boundary.
			if e := phase("audit.release_preparation", p.result.ReleaseExecutable); e != nil {
				return e
			}
			baseline = captured
			if e := phase("audit.accept_generated", func() error { return acceptGeneratedSnapshot(root, &baseline) }); e != nil {
				return e
			}
			return phase("audit.response", func() error {
				request, e := http.NewRequest("GET", "http://"+addr+"/solar/tenants/00000000-0000-0000-0000-00000000000a/projects", nil)
				if e != nil {
					return e
				}
				request.Header.Set("Authorization", "Bearer "+req.Token)
				client := http.Client{Timeout: 10 * time.Second}
				res, e := client.Do(request)
				if e != nil {
					return e
				}
				defer res.Body.Close()
				body, e := io.ReadAll(res.Body)
				if e != nil {
					return e
				}
				var envelope struct {
					Projects []struct {
						Summary string `json:"summary"`
					}
				}
				if e = json.Unmarshal(body, &envelope); e != nil {
					return e
				}
				if res.StatusCode != 200 || len(envelope.Projects) != 1 || envelope.Projects[0].Summary != req.Label {
					return fmt.Errorf("wrong semantic response: %d %s", res.StatusCode, body)
				}
				if res.Header.Get("X-Scenery-Process-Id") != s.current.pid || res.Header.Get("X-Scenery-Build-Input-Digest") != p.result.BuildInput.Digest || res.Header.Get("X-Scenery-Implementation-Revision") != p.result.ImplementationRevisions[p.result.Target.Name] || res.Header.Get("X-Scenery-Contract-Revision") != p.result.Contract.Manifest.ContractRevision {
					return fmt.Errorf("response identity mismatch: %v", res.Header)
				}
				if *direct && req.Proof {
					original := s.current.launch
					if err := owner.EvictCache(); err != nil {
						return err
					}
					// Preflight rejects a false linked identity while the old process remains live.
					bad := *original
					badResult := *original.result
					badInput := *badResult.BuildInput
					badInput.Digest = "sha256:invalid"
					badResult.BuildInput = &badInput
					bad.result = &badResult
					if err := preflightAppStart(ctx, &bad); err == nil {
						return fmt.Errorf("bad preflight admitted")
					}
					if s.current.launch != original {
						return fmt.Errorf("preflight replaced old launch")
					}
					// Real process spawn fails after old child stops; exact retained plan rolls back.
					failed := *original
					failed.request.Command = filepath.Join(out, "missing-candidate")
					previous := s.detachCurrentApp()
					restored, recovered, err := replaceAppGeneration(ctx, previous, &failed, func(a *runningApp) error { return a.stop() }, s.startPreparedApp)
					s.mu.Lock()
					s.current = restored
					s.mu.Unlock()
					if err == nil || !recovered || restored == nil || restored.launch != original {
						return fmt.Errorf("exact native rollback failed: %v", err)
					}
					calls := 0
					retained, recovered, err := replaceAppGeneration(ctx, restored, &failed, func(*runningApp) error { return fmt.Errorf("unconfirmed shutdown") }, func(context.Context, *appStartPlan) (*runningApp, error) { calls++; return nil, nil })
					if err == nil || recovered || retained != restored || calls != 0 {
						return fmt.Errorf("unconfirmed stop allowed admission")
					}
					res2, err := client.Do(request)
					if err != nil {
						return err
					}
					defer res2.Body.Close()
					body2, err := io.ReadAll(res2.Body)
					if err != nil {
						return err
					}
					if res2.StatusCode != 200 || string(body2) != string(body) || res2.Header.Get("X-Scenery-Build-Input-Digest") != p.result.BuildInput.Digest || res2.Header.Get("X-Scenery-Process-Id") != restored.pid {
						return fmt.Errorf("rollback response or bytes differ")
					}
				}
				responseAt = time.Now()
				response = map[string]any{"PID": s.current.pid, "Headers": res.Header, "Body": json.RawMessage(body)}
				return nil
			})
		}()
		record := map[string]any{"OK": err == nil, "PID": os.Getpid(), "Label": req.Label, "StartedAt": start, "CapturedAt": capturedAt, "ResponseAt": responseAt, "CapturedEditToArtifactMS": artifactMS, "Steps": steps, "Response": response}
		if err != nil {
			record["Error"] = err.Error()
			baseline.retryGenerated = true
		} else {
			record["BuildInput"] = p.result.BuildInput
			record["Retained"] = plan.request.Command
			record["Workspace"] = p.result.Dir
			record["GraphCacheHit"] = p.cached != nil
		}
		count, bytes := 0, int64(0)
		filepath.WalkDir(out, func(path string, d os.DirEntry, e error) error {
			if e == nil && !d.IsDir() && (d.Name() == "program" || len(d.Name()) > 12 && d.Name()[:12] == "scenery-app-") {
				if info, e := d.Info(); e == nil {
					count++
					bytes += info.Size()
				}
			}
			return e
		})
		record["ExecutableCount"] = count
		record["ExecutableBytes"] = bytes
		if e := encoder.Encode(record); e != nil {
			return e
		}
	}
}
