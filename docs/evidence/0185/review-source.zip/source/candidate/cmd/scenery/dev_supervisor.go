package main

import (
	"context"
	"crypto/rand"
	"crypto/sha256"
	"database/sql"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log/slog"
	"net"
	"net/http"
	"net/url"
	"os"
	"os/exec"
	"path/filepath"
	"sort"
	"strings"
	"sync"
	"time"
	"unicode/utf8"

	localagent "scenery.sh/internal/agent"
	"scenery.sh/internal/app"
	"scenery.sh/internal/build"
	"scenery.sh/internal/compiler"
	"scenery.sh/internal/devdash"
	"scenery.sh/internal/envfile"
	"scenery.sh/internal/envpolicy"
	"scenery.sh/internal/netprobe"
	"scenery.sh/internal/victoria"
	"scenery.sh/runtime"
)

type runningApp struct {
	process  *devManagedProcess
	cmd      *exec.Cmd
	done     chan error
	buildDir string
	pid      string
	output   *safeLineTail
	launch   *appStartPlan
}

type devSupervisor struct {
	executableOwner       *build.ExecutableOwner
	ctx                   context.Context
	cancel                context.CancelFunc
	root                  string
	cfg                   app.Config
	env                   app.ResolvedEnv
	backend               devBackend
	addr                  string
	invocationEnvironment []string
	worktreeControlPaths  *localagent.Paths
	worktreeRootPaths     *localagent.WorktreePaths
	victoriaDesiredEnv    []string
	victoriaStartupDone   chan struct{}
	victoriaRecoveryDone  <-chan struct{}
	victoriaSubstrateDone <-chan struct{}
	postgresMonitorDone   <-chan struct{}
	postgresTarget        *worktreeDatabaseTarget
	postgresMetadata      *dashboardPostgresDatabase

	store       *devdash.Store
	storeWriter dashboardControlPlaneWriter
	dashboard   *dashboardServer
	victoria    *victoria.Stack
	// victoriaProcesses is an explicit per-supervisor configuration seam for
	// lifecycle tests. Its zero value uses Victoria's environment contract.
	victoriaProcesses victoriaProcessConfig
	storageProxy      *managedStorageProxy
	reportToken       string
	console           *runConsole
	agent             *localagent.Client
	agentSession      *localagent.Session
	// devDomainURL is the edge-verified dev domain base URL advertised in
	// run output; empty when dev.routing.domain does not apply or the edge
	// was not serving it at startup.
	devDomainURL string
	frontends    map[string]*managedFrontendProcess
	desktops     map[string]*managedDesktopProcess
	// desktopSessionProcessUpdater is an in-process lifecycle seam. Production
	// leaves it nil and updates the registered local-agent session.
	desktopSessionProcessUpdater func(context.Context, string, int) error
	assistants                   *assistantSupervisor
	// assistantTokenKeyPath is the supervisor-owned stable sealing key handed
	// to the app child. It is kept out of ordinary status and log payloads.
	assistantTokenKeyPath string
	// productionFrontends holds in-process static servers for frontends with
	// serve mode "production", keyed by normalized frontend name; guarded by mu.
	productionFrontends map[string]*staticFrontendServer
	events              *devEventSink

	closeOnce          sync.Once
	mu                 sync.RWMutex
	current            *runningApp
	status             devdash.AppRecord
	pendingDevEvents   []devdash.DevEvent
	startupReady       <-chan error
	victoriaStarted    bool
	dbSetupFingerprint string
	buildFailed        bool

	// rebuildRequests wakes the watch loop for a rebuild that no watched
	// file change would trigger (e.g. a ui catalog sync succeeding after the
	// last app build failed). Buffered so requests never block; coalescing
	// duplicate requests into one pending wake is the desired behavior.
	rebuildRequests chan struct{}
}

const (
	appStartupTimeout      = 30 * time.Second
	appStartupPollInterval = 10 * time.Millisecond
)

func newDevSupervisor(ctx context.Context, root string, cfg app.Config, env app.ResolvedEnv, backend devBackend, console *runConsole, agent *localagent.Client, agentSession *localagent.Session) (*devSupervisor, error) {
	supervisorCtx, cancel := context.WithCancel(ctx)
	backend = backend.normalized()
	token, err := randomToken()
	if err != nil {
		cancel()
		return nil, err
	}
	if agent == nil || agentSession == nil {
		cancel()
		return nil, fmt.Errorf("development supervisor requires its acquired worktree control owner")
	}
	storeWriter, err := newDashboardControlPlaneClient(ctx, agent, *agentSession, token)
	if err != nil {
		cancel()
		return nil, err
	}
	appID := cfg.AppID()
	if console == nil {
		console = newRunConsole(os.Stdout, os.Stderr, false, false, appID, root)
	}

	s := &devSupervisor{
		ctx:          supervisorCtx,
		cancel:       cancel,
		root:         root,
		cfg:          cfg,
		env:          env,
		backend:      backend,
		addr:         backend.Addr,
		storeWriter:  storeWriter,
		reportToken:  token,
		console:      console,
		agent:        agent,
		agentSession: agentSession,
		status: devdash.AppRecord{
			ID:         appID,
			Name:       cfg.Name,
			Root:       root,
			ListenAddr: backend.Addr,
			Offline:    true,
			UpdatedAt:  time.Now().UTC(),
		},
		rebuildRequests: make(chan struct{}, 1),
	}
	assistantStateRoot := filepath.Join(root, ".scenery", "assistants")
	if agentSession != nil && strings.TrimSpace(agentSession.StateRoot) != "" {
		assistantStateRoot = filepath.Join(agentSession.StateRoot, "assistants")
	}
	assistantTokenKeyPath, keyErr := ensureAssistantTokenKey(assistantStateRoot)
	if keyErr != nil {
		cancel()
		return nil, fmt.Errorf("assistant token key: %w", keyErr)
	}
	assistantAppEnv, envErr := appEnvWithDotEnv(envpolicy.Environ(), root, env.DotEnvFiles()...)
	if envErr != nil {
		cancel()
		return nil, fmt.Errorf("assistant provider environment: %w", envErr)
	}
	s.assistants = newAssistantSupervisor(supervisorCtx, assistantSupervisorConfig{
		Root:          root,
		StateRoot:     assistantStateRoot,
		ProviderEnv:   assistantProviderEnv(assistantAppEnv),
		UseAppGateway: true,
		OnProcess: func(name string, pid int) {
			if s == nil {
				return
			}
			if s.agent != nil {
				s.updateAgentSession(context.Background(), "running", s.currentPID())
			}
		},
		OnEvent: func(ctx context.Context, source devdash.DevSource, level, message string, fields map[string]any) {
			s.eventSink().Emit(ctx, source, level, message, fields)
			if message == "assistant.step" && s.console != nil {
				s.console.Event("build.step", fields)
			}
		},
		OnStatus: func(statuses []AssistantStatusRecord) {
			s.persistAssistantStatusSnapshot(statuses)
		},
		Output:    os.Stdout,
		ErrOutput: os.Stderr,
	})
	s.assistantTokenKeyPath = assistantTokenKeyPath
	s.dashboard = newDashboardServer(s, "")
	s.events = newDevEventSink(s)
	return s, nil
}

func (s *devSupervisor) eventSink() *devEventSink {
	if s == nil {
		return nil
	}
	if s.events == nil {
		s.events = newDevEventSink(s)
	}
	return s.events
}

func (s *devSupervisor) Close() error {
	var closeErr error
	s.closeOnce.Do(func() {
		if s.cancel != nil {
			s.cancel()
		}
		if s.postgresMonitorDone != nil {
			<-s.postgresMonitorDone
		}
		if s.victoriaStartupDone != nil {
			<-s.victoriaStartupDone
		}
		// Assistant helpers own private gateways and control clients. Stop them
		// before tearing down the ordinary app so no helper can outlive the
		// session it serves.
		if s.assistants != nil {
			if err := s.assistants.Close(); err != nil {
				closeErr = errors.Join(closeErr, err)
			}
		}

		app := s.detachCurrentApp()
		frontends := s.detachManagedFrontends()
		desktops := s.detachManagedDesktops()
		s.mu.RLock()
		victoria := s.victoria
		s.mu.RUnlock()

		var errs []error
		if app != nil {
			if err := app.interrupt(); err != nil {
				errs = append(errs, err)
			}
		}
		if victoria != nil {
			if err := victoria.Interrupt(); err != nil {
				errs = append(errs, err)
			}
		}

		type closer struct {
			name string
			fn   func() error
		}
		closers := []closer{}
		if s.dashboard != nil {
			closers = append(closers, closer{name: "dashboard", fn: s.dashboard.Close})
		}
		if s.storageProxy != nil {
			closers = append(closers, closer{name: "storage-proxy", fn: s.storageProxy.Close})
		}

		if len(closers) > 0 {
			errCh := make(chan error, len(closers))
			var wg sync.WaitGroup
			for _, item := range closers {
				wg.Add(1)
				go func(fn func() error) {
					defer wg.Done()
					if err := fn(); err != nil {
						errCh <- err
					}
				}(item.fn)
			}
			done := make(chan struct{})
			go func() {
				wg.Wait()
				close(errCh)
				close(done)
			}()
			select {
			case <-done:
				for err := range errCh {
					errs = append(errs, err)
				}
			case <-time.After(2 * time.Second):
				errs = append(errs, fmt.Errorf("timed out closing in-process dev services"))
			}
		}

		if app != nil {
			if err := app.waitOrKill(stopTimeout); err != nil {
				errs = append(errs, err)
			} else if app.launch != nil && app.launch.executable != nil {
				errs = append(errs, app.launch.executable.Release())
			}
		}
		for _, frontend := range frontends {
			if err := frontend.Stop(); err != nil {
				errs = append(errs, err)
			}
		}
		for _, desktop := range desktops {
			if err := desktop.Stop(); err != nil {
				errs = append(errs, err)
			}
		}
		if victoria != nil {
			if err := victoria.WaitOrKill(5 * time.Second); err != nil {
				errs = append(errs, err)
			}
		}
		for _, done := range []<-chan struct{}{s.victoriaRecoveryDone, s.victoriaSubstrateDone} {
			if done != nil {
				<-done
			}
		}

		if s.executableOwner != nil {
			errs = append(errs, s.executableOwner.Close())
		}
		if s.store != nil {
			if err := s.store.Close(); err != nil {
				errs = append(errs, err)
			}
		}
		if s.worktreeRootPaths != nil {
			stopCtx, cancel := context.WithTimeout(context.Background(), 20*time.Second)
			record, err := s.worktreeRootPaths.LoadRecord(s.cfg.AppID())
			if err != nil {
				errs = append(errs, err)
			} else if record.Postgres != nil {
				resolver, resolveErr := newWorktreePostgresResolver(stopCtx, s.root, s.cfg.AppID())
				if resolveErr == nil {
					resolveErr = resolver.stop(stopCtx)
				}
				if resolveErr != nil {
					errs = append(errs, resolveErr)
				}
			}
			cancel()
		}
		if session := s.currentAgentSession(); s.agent != nil && session != nil {
			if _, _, err := s.agent.DeleteOwnedSession(context.Background(), *session, false); err != nil {
				errs = append(errs, err)
			}
		}
		closeErr = errors.Join(append([]error{closeErr}, errs...)...)
	})
	return closeErr
}

func (s *devSupervisor) Start(ctx context.Context) error {
	if err := s.configureWorktreeVictoria(); err != nil {
		s.reportVictoriaRecoveryFailure("", err, 0)
	}
	s.setSessionIdentity(s.currentAgentSession())
	s.updateAgentSession(ctx, "starting", "")
	s.eventSink().Emit(ctx, devdash.DevSource{ID: "supervisor", Kind: "supervisor", Name: "supervisor", Status: "starting"}, "info", "dev supervisor starting", map[string]any{
		"listen_addr":    s.addr,
		"listen_network": s.backend.Network,
	})
	if s.console != nil {
		s.console.Event("run.start", map[string]any{
			"listen_addr":    s.addr,
			"listen_network": s.backend.Network,
		})
	}
	if err := ensureSceneryLocalStateIgnored(s.root); err != nil {
		return err
	}
	if err := s.persistStatus(ctx); err != nil {
		return err
	}
	if s.agent == nil {
		if err := s.dashboard.Start(ctx); err != nil {
			return err
		}
	}
	ready := s.startDevServiceStartup(s.ctx)
	s.mu.Lock()
	s.startupReady = ready
	s.mu.Unlock()
	s.startPostgresEndpointMonitor()
	return nil
}

func (s *devSupervisor) startDevServiceStartup(ctx context.Context) <-chan error {
	done := make(chan error, 1)
	s.victoriaStartupDone = make(chan struct{})
	go func() {
		var wg sync.WaitGroup
		errCh := make(chan error, 2)
		wg.Add(1)
		go func() {
			defer wg.Done()
			if err := s.console.Phase("Starting storage proxy", func() error {
				return s.ensureManagedStorageProxy(ctx)
			}); err != nil {
				errCh <- err
			}
		}()
		go func() {
			defer close(s.victoriaStartupDone)
			var victoriaStack *victoria.Stack
			_ = s.console.Phase("Starting Victoria observability stack", func() error {
				victoriaStack = s.startVictoriaStack(ctx)
				return nil
			})
			if ctx.Err() != nil {
				discardVictoriaStack(victoriaStack)
				return
			}
			s.mu.Lock()
			s.victoria = victoriaStack
			s.victoriaStarted = true
			pendingDevEvents := append([]devdash.DevEvent(nil), s.pendingDevEvents...)
			s.pendingDevEvents = nil
			s.mu.Unlock()
			if s.agent != nil && victoria.Enabled() {
				s.startVictoriaRecoveryMonitor()
			}
			if victoriaStack != nil {
				for _, event := range pendingDevEvents {
					s.eventSink().ExportVictoriaDevEvent(event)
				}
				s.eventSink().Emit(ctx, devdash.DevSource{ID: "victoria", Kind: "substrate", Name: "victoria", Role: "observability", Status: "running"}, "info", "Victoria stack ready", map[string]any{
					"urls": victoriaStack.URLs(),
				})
			}
		}()
		wg.Wait()
		close(errCh)
		var errs []error
		for err := range errCh {
			if err != nil {
				errs = append(errs, err)
			}
		}
		err := errors.Join(errs...)
		if err != nil && s.cancel != nil {
			s.cancel()
		}
		done <- err
		close(done)
	}()
	return done
}

func (s *devSupervisor) waitForStartupReady(ctx context.Context) error {
	s.mu.RLock()
	ready := s.startupReady
	s.mu.RUnlock()
	if ready == nil {
		return nil
	}
	select {
	case err := <-ready:
		s.mu.Lock()
		if s.startupReady == ready {
			s.startupReady = nil
		}
		s.mu.Unlock()
		return err
	case <-ctx.Done():
		return ctx.Err()
	}
}

func (s *devSupervisor) addStartupReady(ready <-chan error) {
	if s == nil || ready == nil {
		return
	}
	s.mu.Lock()
	existing := s.startupReady
	s.startupReady = joinStartupReady(existing, ready)
	s.mu.Unlock()
}

func joinStartupReady(left, right <-chan error) <-chan error {
	if left == nil {
		return right
	}
	if right == nil {
		return left
	}
	done := make(chan error, 1)
	go func() {
		done <- errors.Join(<-left, <-right)
		close(done)
	}()
	return done
}

func (s *devSupervisor) startVictoriaStack(ctx context.Context) *victoria.Stack {
	if s == nil || s.agent == nil {
		return nil
	}
	paths, err := s.controlPaths()
	if err != nil {
		victoria.Warn(victoriaConsole(s.console), "agent Victoria state path unavailable: %v", err)
		return nil
	}
	stack, reused, err := s.ensureVictoriaStack(ctx, filepath.Join(paths.AgentDir, "victoria"))
	if err != nil {
		victoria.Warn(victoriaConsole(s.console), "failed to prepare worktree Victoria substrate with agent: %v", err)
		return stack
	}
	if stack == nil {
		return nil
	}
	s.victoriaSubstrateDone = monitorVictoriaSubstrate(filepath.Join(paths.AgentDir, "victoria"), s.agent, s.eventSink(), stack)
	if s.console != nil && s.console.verbose {
		s.console.Event("victoria.worktree", map[string]any{
			"owner":     "worktree",
			"mode":      "worktree-owner",
			"reused":    reused,
			"endpoints": stack.SubstrateRequest(os.Getpid()).Endpoints,
		})
	}
	return stack
}

func (s *devSupervisor) assistantRuntimeConfigPath() string {
	if s == nil || s.assistants == nil {
		return ""
	}
	return filepath.Join(s.root, ".scenery", "run", "assistant-runtime.json")
}

func (s *devSupervisor) refreshAssistantRuntimeConfig() {
	if s == nil || s.assistants == nil {
		return
	}
	path := s.assistantRuntimeConfigPath()
	if path == "" {
		return
	}
	if err := runtime.WriteAssistantRuntimeConfig(path, s.assistants.RuntimeConfig()); err != nil {
		s.eventSink().Emit(context.Background(), devdash.DevSource{ID: "assistant-runtime", Kind: "assistant", Name: "assistant-runtime", Role: "assistant-bootstrap", Status: "error"}, "error", "assistant runtime config unavailable", map[string]any{"error": err.Error()})
	}
}

func (s *devSupervisor) managedAppEnv(ctx context.Context, baseEnv []string, requirements compiler.SQLRequirements) ([]string, error) {
	env, database, err := managedDatabaseEnv(ctx, s.root, s.cfg, requirements, baseEnv)
	if err != nil {
		return nil, err
	}
	s.rememberWorktreeDatabase(database, s.cfg.AppID())
	emitPostgresReadyEvents(ctx, s.eventSink(), database)
	return env, nil
}

func (s *devSupervisor) processEnvironment() []string {
	if s.invocationEnvironment != nil {
		return s.invocationEnvironment
	}
	return envpolicy.Environ()
}

func (s *devSupervisor) appDatabaseAuthorityEnv(baseEnv []string, requirements compiler.SQLRequirements) []string {
	if s == nil {
		return baseEnv
	}
	if len(requirements) > 0 {
		return envWithoutKeys(baseEnv, databaseEnvKeys(requirements)...)
	}
	return baseEnv
}

func (s *devSupervisor) sessionIdentityEnv() []string {
	session := s.currentAgentSession()
	if session == nil {
		return nil
	}
	baseAppID := strings.TrimSpace(session.BaseAppID)
	if baseAppID == "" {
		baseAppID = s.activeAppID()
	}
	runtimeAppID := strings.TrimSpace(session.RuntimeAppID)
	if runtimeAppID == "" {
		runtimeAppID = baseAppID
	}
	return []string{
		"SCENERY_SESSION_ID=" + strings.TrimSpace(session.SessionID),
		"SCENERY_BASE_APP_ID=" + baseAppID,
		"SCENERY_RUNTIME_APP_ID=" + runtimeAppID,
		"SCENERY_APP_ROOT_HASH=" + appRootHash(session.AppRoot),
		"SCENERY_BRANCH=" + strings.TrimSpace(session.Branch),
		"SCENERY_WORKTREE=" + appWorktreeName(session.AppRoot),
		"SCENERY_ROUTE_MODE=" + string(firstRouteMode(session)),
		"SCENERY_BASE_URL=" + strings.TrimSpace(session.RouteManifest.BaseURL),
		"SCENERY_API_URL=" + strings.TrimSpace(session.RouteManifest.Routes[localagent.RouteAPI].URL),
		"SCENERY_API_BASE_PATH=" + routeBasePath(session, localagent.RouteAPI),
		"SCENERY_PUBLIC_APP_URL=" + publicAppURLForSession(session),
	}
}

func firstRouteMode(session *localagent.Session) localagent.RouteMode {
	if session == nil {
		return localagent.RouteModeHost
	}
	if session.RouteManifest.Mode != "" {
		return session.RouteManifest.Mode
	}
	return localagent.RouteModeHost
}

func routeBasePath(session *localagent.Session, name string) string {
	if session == nil || session.RouteManifest.Routes == nil {
		return ""
	}
	record, ok := session.RouteManifest.Routes[name]
	if !ok {
		return ""
	}
	return strings.TrimSpace(record.Path)
}

func publicAppURLForSession(session *localagent.Session) string {
	if session == nil {
		return ""
	}
	if root := session.RouteManifest.Routes["root"]; strings.TrimSpace(root.Kind) == "frontend" && strings.TrimSpace(root.URL) != "" {
		return strings.TrimSpace(root.URL)
	}
	names := make([]string, 0, len(session.RouteManifest.Routes))
	for name, record := range session.RouteManifest.Routes {
		if name == localagent.RouteAPI || name == localagent.RouteDashboard || name == "root" {
			continue
		}
		if strings.TrimSpace(record.URL) != "" {
			names = append(names, name)
		}
	}
	sort.Strings(names)
	if len(names) > 0 {
		return strings.TrimSpace(session.RouteManifest.Routes[names[0]].URL)
	}
	return strings.TrimSpace(firstNonEmpty(session.RouteManifest.BaseURL, session.RouteManifest.Routes[localagent.RouteAPI].URL))
}

func appRootHash(root string) string {
	root = filepath.Clean(strings.TrimSpace(root))
	if root == "" || root == "." {
		return ""
	}
	sum := sha256.Sum256([]byte(root))
	return hex.EncodeToString(sum[:])[:12]
}

func appWorktreeName(root string) string {
	root = filepath.Clean(strings.TrimSpace(root))
	if root == "" || root == "." {
		return ""
	}
	return filepath.Base(root)
}

func (s *devSupervisor) devReportURL() string {
	if s != nil && s.agent != nil {
		ctx, cancel := context.WithTimeout(context.Background(), 500*time.Millisecond)
		defer cancel()
		if health, err := s.agent.Health(ctx); err == nil {
			if rawURL := reportURLForBackend(health.DashboardBackend); rawURL != "" {
				return rawURL
			}
		}
		if session := s.currentAgentSession(); session != nil {
			if rawURL := reportURLForBackend(session.Backends[localagent.RouteDashboard]); rawURL != "" {
				return rawURL
			}
		}
	}
	return "http://" + devdash.ListenAddr() + devdash.ReportPath
}

func reportURLForBackend(backend localagent.Backend) string {
	network := strings.TrimSpace(backend.Network)
	addr := strings.TrimSpace(backend.Addr)
	if addr == "" || (network != "" && network != "tcp") {
		return ""
	}
	return "http://" + addr + devdash.ReportPath
}

func (s *devSupervisor) sessionAuthEnv() []string {
	if s == nil || !s.cfg.Auth.Enabled {
		return nil
	}
	apiURL := strings.TrimSpace(s.apiURL())
	if apiURL == "" {
		return nil
	}
	publicAppURL := apiURL
	frontends := s.frontendURLs()
	if len(frontends) > 0 {
		names := make([]string, 0, len(frontends))
		for name := range frontends {
			names = append(names, name)
		}
		sort.Strings(names)
		if value := strings.TrimSpace(frontends[names[0]]); value != "" {
			publicAppURL = value
		}
	}
	return []string{
		"SCENERY_API_BASE_URL=" + apiURL,
		"SCENERY_PUBLIC_APP_URL=" + publicAppURL,
		"AUTH_COOKIE_DOMAIN=",
	}
}

func (s *devSupervisor) waitForAppStartup(ctx context.Context, app *runningApp) error {
	if app == nil || app.process == nil {
		deadline := time.NewTimer(appStartupTimeout)
		defer deadline.Stop()
		ticker := time.NewTicker(appStartupPollInterval)
		defer ticker.Stop()
		for {
			select {
			case <-ctx.Done():
				_ = app.stop()
				return ctx.Err()
			case err, ok := <-app.done:
				if !ok {
					return appStartupExitError(app, nil)
				}
				return appStartupExitError(app, err)
			case <-ticker.C:
				if backendAcceptsConnections(s.backend) {
					return nil
				}
			case <-deadline.C:
				_ = app.stop()
				return fmt.Errorf("scenery app did not listen on %s address %s within %s", s.backend.Network, s.addr, appStartupTimeout)
			}
		}
	}
	return app.process.WaitReady(ctx, devProcessReadyRequest{
		Timeout:  appStartupTimeout,
		Interval: appStartupPollInterval,
		Probe: func(context.Context) error {
			if backendAcceptsConnections(s.backend) {
				return nil
			}
			return fmt.Errorf("scenery app is not accepting %s connections on %s", s.backend.Network, s.addr)
		},
	})
}

func appStartupExitError(app *runningApp, err error) error {
	message := "scenery app exited during startup"
	if err != nil {
		message += ": " + err.Error()
	} else {
		message += ": process exited without an error"
	}
	if app != nil && app.output != nil {
		if output := strings.TrimSpace(app.output.String()); output != "" {
			message += "\n" + output
		}
	}
	return errors.New(message)
}

func backendAcceptsConnections(backend devBackend) bool {
	backend = backend.normalized()
	target := backend.Addr
	if backend.Network == "tcp" {
		if host, port, err := net.SplitHostPort(backend.Addr); err == nil && host == "" {
			target = net.JoinHostPort("127.0.0.1", port)
		}
	}
	conn, err := net.DialTimeout(backend.Network, target, 100*time.Millisecond)
	if err != nil {
		return false
	}
	_ = conn.Close()
	return true
}

func backendAvailableBeforeStartup(backend devBackend) error {
	backend = backend.normalized()
	if backend.Network == "unix" {
		return nil
	}
	return portAvailable(backend.Addr)
}

func tcpAddrAcceptsConnections(addr string) bool {
	return netprobe.DialReachable(addr, 100*time.Millisecond)
}

func (s *devSupervisor) processOutputWriter(dst io.Writer) io.Writer {
	if s != nil && s.console != nil && s.console.json {
		return nil
	}
	if s != nil && s.console != nil && s.console.palette.Enabled() {
		return &devProcessOutputWriter{dst: dst, palette: s.console.palette}
	}
	return dst
}

func (s *devSupervisor) processOutputFilter(pid int, stream string, data []byte) []byte {
	return data
}

func appChildEnv(base []string, forceColor bool, vars ...string) []string {
	env := append(append([]string(nil), base...), vars...)
	if forceColor {
		env = append(env, "CLICOLOR_FORCE=1")
	}
	return env
}

func envWithoutKeys(base []string, keys ...string) []string {
	if len(keys) == 0 {
		return append([]string(nil), base...)
	}
	omit := make(map[string]struct{}, len(keys))
	for _, key := range keys {
		omit[key] = struct{}{}
	}
	env := make([]string, 0, len(base))
	for _, item := range base {
		key, _, ok := strings.Cut(item, "=")
		if ok {
			if _, drop := omit[key]; drop {
				continue
			}
		}
		env = append(env, item)
	}
	return env
}

func appEnvWithDotEnv(base []string, root string, names ...string) ([]string, error) {
	if len(names) == 0 {
		names = []string{".env"}
	}
	values, err := envfile.MergeFiles(root, names...)
	if err != nil {
		return nil, &codedCLIError{err: err, code: 3}
	}
	return envfile.AppendMissing(base, values), nil
}

func (s *devSupervisor) handleExit(ctx context.Context, app *runningApp) {
	if app == nil {
		return
	}
	s.mu.Lock()
	if s.current == nil || s.current.pid != app.pid {
		s.mu.Unlock()
		return
	}
	s.current = nil
	s.status.Running = false
	s.status.Offline = true
	s.status.PID = ""
	s.status.UpdatedAt = time.Now().UTC()
	s.mu.Unlock()

	_ = s.persistStatus(ctx)
	s.dashboard.notify(&devdash.Notification{
		Method: "process/stop",
		Params: s.appStatus(),
	})
	s.writeProcessEvent(ctx, "process-stop", s.compactAppStatus())
	if s.console != nil {
		s.console.Event("process.stop", map[string]any{
			"pid": app.pid,
		})
	}
	s.updateAgentSession(ctx, "stopped", "")
}

func (a *runningApp) interrupt() error {
	if a != nil && a.process != nil {
		return a.process.Interrupt()
	}
	if a == nil || a.cmd == nil || a.cmd.Process == nil {
		return nil
	}
	return interruptProcessTree(a.cmd)
}

func (a *runningApp) kill() error {
	if a != nil && a.process != nil {
		if a.process.Cmd != nil {
			return killProcessTree(a.process.Cmd)
		}
		return nil
	}
	if a == nil || a.cmd == nil || a.cmd.Process == nil {
		return nil
	}
	return killProcessTree(a.cmd)
}

func (a *runningApp) waitOrKill(grace time.Duration) error {
	if a == nil {
		return nil
	}
	if a.process != nil {
		return a.process.WaitOrKill(grace)
	}
	select {
	case err := <-a.done:
		if err == nil || isExpectedExit(err) {
			return nil
		}
		return err
	case <-time.After(grace):
		_ = a.kill()
		select {
		case err := <-a.done:
			if err == nil || isExpectedExit(err) {
				return nil
			}
			return err
		case <-time.After(time.Second):
			return fmt.Errorf("app did not exit after SIGKILL")
		}
	}
}

func (a *runningApp) stop() error {
	if a != nil && a.process != nil {
		return a.process.Stop(stopTimeout)
	}
	if err := a.interrupt(); err != nil {
		return err
	}
	return a.waitOrKill(stopTimeout)
}

func validateLocalSecretsFiles(root string, cfg app.Config, env app.ResolvedEnv) error {
	values, err := appEnvWithDotEnv(envpolicy.Environ(), root, env.DotEnvFiles()...)
	if err != nil {
		return err
	}
	if env.Deployable() && cfg.Auth.Enabled {
		var required []string
		if value := lookupEnvValue(values, "JWT_SECRET"); strings.TrimSpace(value) == "" {
			required = append(required, "JWT_SECRET")
		}
		if cfg.Auth.GoogleOAuth.Enabled {
			for _, name := range []string{"GOOGLE_OAUTH_CLIENT_ID", "GOOGLE_OAUTH_CLIENT_SECRET", "AUTH_TOKEN_CIPHER_KEY"} {
				if value := lookupEnvValue(values, name); strings.TrimSpace(value) == "" {
					required = append(required, name)
				}
			}
		}
		if len(required) > 0 {
			return &codedCLIError{err: fmt.Errorf("environment %q is missing required secrets: %s", env.Name, strings.Join(required, ", ")), code: 3}
		}
	}
	return nil
}

func (s *devSupervisor) persistStatus(ctx context.Context) error {
	s.mu.RLock()
	status := s.status
	s.mu.RUnlock()
	status.Metadata = s.metadataWithRuntimePostgresDatabases(status.Metadata, status.Root)
	if s.storeWriter == nil {
		return nil
	}
	return s.storeWriter.UpsertApp(ctx, status)
}

func (s *devSupervisor) writeProcessEvent(ctx context.Context, kind string, payload any) {
	if s == nil {
		return
	}
	if s.storeWriter == nil && s.store != nil {
		s.storeWriter = localDashboardControlPlaneWriter{store: s.store}
	}
	if s.storeWriter == nil {
		return
	}
	_ = s.storeWriter.WriteProcessEvent(ctx, s.activeAppID(), s.currentSessionID(), kind, payload)
}

func (s *devSupervisor) setCompiling(compiling bool, compileErr string) {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.status.Compiling = compiling
	s.status.CompileError = compileErr
	s.status.UpdatedAt = time.Now().UTC()
}

func (s *devSupervisor) setMetadata(metadata, apiEncoding json.RawMessage) {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.status.Metadata = metadata
	s.status.APIEncoding = apiEncoding
	s.status.UpdatedAt = time.Now().UTC()
}

func (s *devSupervisor) setRunning(pid string, metadata, apiEncoding json.RawMessage) {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.status.Running = true
	s.status.Offline = false
	s.status.PID = pid
	s.status.ListenAddr = s.addr
	s.status.Metadata = metadata
	s.status.APIEncoding = apiEncoding
	s.status.CompileError = ""
	s.status.UpdatedAt = time.Now().UTC()
}

func (s *devSupervisor) setSessionIdentity(session *localagent.Session) {
	if s == nil || session == nil {
		return
	}
	baseAppID := strings.TrimSpace(session.BaseAppID)
	if baseAppID == "" {
		baseAppID = s.activeAppID()
	}
	runtimeAppID := strings.TrimSpace(session.RuntimeAppID)
	if runtimeAppID == "" {
		runtimeAppID = baseAppID
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	s.status.BaseAppID = baseAppID
	s.status.RuntimeAppID = runtimeAppID
	s.status.SessionID = strings.TrimSpace(session.SessionID)
	s.status.UpdatedAt = time.Now().UTC()
}

func (s *devSupervisor) currentSessionID() string {
	if s == nil {
		return ""
	}
	s.mu.RLock()
	defer s.mu.RUnlock()
	return s.status.SessionID
}

// currentAgentSession returns the latest agent session snapshot. Stored
// sessions are immutable: writers register a refreshed session with the agent
// and publish it via storeAgentSession instead of mutating fields in place.
func (s *devSupervisor) currentAgentSession() *localagent.Session {
	if s == nil {
		return nil
	}
	s.mu.RLock()
	defer s.mu.RUnlock()
	return s.agentSession
}

func (s *devSupervisor) storeAgentSession(session *localagent.Session) {
	if s == nil || session == nil {
		return
	}
	s.mu.Lock()
	s.agentSession = session
	s.mu.Unlock()
	s.setSessionIdentity(session)
}

func (s *devSupervisor) detachCurrentApp() *runningApp {
	s.mu.Lock()
	defer s.mu.Unlock()
	current := s.current
	s.current = nil
	return current
}

func (s *devSupervisor) announceRebuild(paths []string) {
	if s.console != nil {
		s.console.RebuildDetected(paths)
	}
}

func (s *devSupervisor) apiURL() string {
	if session := s.currentAgentSession(); session != nil && session.RouteManifest.Routes[localagent.RouteAPI].URL != "" {
		return session.RouteManifest.Routes[localagent.RouteAPI].URL
	}
	return "http://" + s.addr
}

func (s *devSupervisor) dashboardURL() string {
	if session := s.currentAgentSession(); session != nil && session.RouteManifest.Routes[localagent.RouteDashboard].URL != "" {
		return session.RouteManifest.Routes[localagent.RouteDashboard].URL
	}
	return "http://" + devdash.ListenAddr() + "/" + url.PathEscape(s.activeAppID())
}

func (s *devSupervisor) frontendURLs() map[string]string {
	if session := s.currentAgentSession(); session != nil {
		return frontendURLsFromAgentRoutes(session.RouteManifest.URLs(), s.cfg.Frontends)
	}
	return nil
}

func substrateExitEventFields(exit localagent.SubstrateExit) map[string]any {
	fields := map[string]any{
		"component":       exit.Component,
		"pid":             exit.PID,
		"started_at":      exit.StartedAt,
		"exited_at":       exit.ExitedAt,
		"exit_code":       exit.ExitCode,
		"log_path":        exit.LogPath,
		"stdout_log_path": exit.StdoutLogPath,
		"stderr_log_path": exit.StderrLogPath,
	}
	if exit.Signal != "" {
		fields["signal"] = exit.Signal
	}
	if exit.Error != "" {
		fields["error"] = exit.Error
	}
	return fields
}

func (s *devSupervisor) activeAppID() string {
	s.mu.RLock()
	defer s.mu.RUnlock()
	return s.activeAppIDLocked()
}

// activeAppIDLocked requires s.mu to be held. The s.cfg fallback only applies
// before setAppIdentity has run, when no other goroutines are active.
func (s *devSupervisor) activeAppIDLocked() string {
	if s.status.ID != "" {
		return s.status.ID
	}
	return s.cfg.AppID()
}

func (s *devSupervisor) dashboardActiveAppID() string {
	return s.activeAppID()
}

func (s *devSupervisor) dashboardCurrentSessionID() string {
	return s.currentSessionID()
}

func (s *devSupervisor) dashboardListApps(ctx context.Context) ([]map[string]any, error) {
	return s.listApps(ctx)
}

func (s *devSupervisor) dashboardStatusFor(ctx context.Context, appID string) (devdash.AppStatus, error) {
	return s.statusFor(ctx, appID)
}

func (s *devSupervisor) dashboardStore() *devdash.Store {
	return s.store
}

func (s *devSupervisor) dashboardAuthorizeReport(req *http.Request, report devdash.ReportEnvelope) dashboardReportAuth {
	if report.SessionID != "" && report.SessionID != s.currentSessionID() {
		return dashboardReportAuth{Reason: "stale-session"}
	}
	if req.Header.Get("Authorization") != "Bearer "+s.reportToken {
		return dashboardReportAuth{Reason: "invalid-report-token"}
	}
	return dashboardReportAuth{Authorized: true}
}

func (s *devSupervisor) dashboardVictoria() dashboardVictoria {
	if s == nil {
		return nil
	}
	s.mu.RLock()
	victoria := s.victoria
	s.mu.RUnlock()
	if victoria == nil {
		return nil
	}
	return victoria
}

func (s *devSupervisor) setAppIdentity(cfg app.Config) {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.status.ID = cfg.AppID()
	s.status.Name = cfg.Name
	s.status.UpdatedAt = time.Now().UTC()
}

func frontendURLsFromAgentRoutes(routes map[string]string, frontends map[string]app.FrontendConfig) map[string]string {
	if len(routes) == 0 {
		return nil
	}
	names := make([]string, 0, len(frontends))
	if len(frontends) > 0 {
		for name := range frontends {
			value := strings.TrimSpace(routes[name])
			if value == "" {
				continue
			}
			names = append(names, name)
		}
	} else {
		for name, value := range routes {
			switch name {
			case localagent.RouteAPI, localagent.RouteDashboard:
				continue
			}
			if strings.TrimSpace(value) == "" {
				continue
			}
			names = append(names, name)
		}
	}
	if len(names) == 0 {
		return nil
	}
	sort.Strings(names)
	urls := make(map[string]string, len(names))
	for _, name := range names {
		urls[name] = routes[name]
	}
	return urls
}

func (s *devSupervisor) runURLs() runURLs {
	return runURLs{
		App:       s.devDomainURL,
		API:       s.apiURL(),
		Dashboard: s.dashboardURL(),
		Frontends: s.frontendURLs(),
		Victoria:  s.victoria.URLs(),
	}
}

func (s *devSupervisor) handleCompileError(ctx context.Context, metadata, apiEncoding json.RawMessage, err error) error {
	s.mu.Lock()
	s.buildFailed = true
	s.mu.Unlock()
	s.setCompiling(false, err.Error())
	if s.currentPID() == "" && (len(metadata) > 0 || len(apiEncoding) > 0) {
		s.setMetadata(metadata, apiEncoding)
	}
	_ = s.persistStatus(ctx)
	s.dashboard.notify(&devdash.Notification{
		Method: "process/compile-error",
		Params: s.appStatus(),
	})
	s.writeProcessEvent(ctx, "compile-error", map[string]any{"error": err.Error()})
	s.eventSink().Emit(ctx, devdash.DevSource{ID: "build", Kind: "build", Name: "build", Status: "error", Reason: err.Error()}, "error", "build failed", map[string]any{
		"error": err.Error(),
	})
	if s.console != nil {
		s.console.Event("process.compile-error", map[string]any{
			"error": err.Error(),
		})
	}
	if pid := s.currentPID(); pid != "" {
		s.updateAgentSession(ctx, "running", pid)
	} else {
		s.updateAgentSession(ctx, "compile-error", "")
	}
	return err
}

// RequestRebuildIfBuildFailed wakes the watch loop for a full rebuild when the
// last app build failed. External fix paths whose writes do not surface as
// watched file changes (like a ui catalog sync succeeding after its earlier
// failure kept the app build stale) call this so a failed session converges
// instead of latching in compile-error until the next unrelated edit.
func (s *devSupervisor) RequestRebuildIfBuildFailed() {
	s.mu.RLock()
	failed := s.buildFailed
	s.mu.RUnlock()
	if !failed {
		return
	}
	select {
	case s.rebuildRequests <- struct{}{}:
	default:
	}
}

// rebuildRequestChan exposes the wake signal for the watch loop.
func (s *devSupervisor) rebuildRequestChan() <-chan struct{} {
	return s.rebuildRequests
}

// compactAppStatus is appStatus without the Meta and APIEncoding blobs, which
// can run to megabytes per app. Persisted process events must use this form;
// stored events are breadcrumbs and the full model is always available live.
func (s *devSupervisor) compactAppStatus() devdash.AppStatus {
	status := s.appStatus()
	status.Meta = nil
	status.APIEncoding = nil
	return status
}

func (s *devSupervisor) appStatus() devdash.AppStatus {
	s.mu.RLock()
	var session *localagent.Session
	if s.agentSession != nil {
		copy := *s.agentSession
		session = &copy
	}
	victoria := s.victoria
	status := devdash.AppStatus{
		Running:       s.status.Running,
		AppID:         s.status.ID,
		BaseAppID:     s.status.BaseAppID,
		RuntimeAppID:  s.status.RuntimeAppID,
		SessionID:     s.status.SessionID,
		AppRoot:       s.status.Root,
		PID:           s.status.PID,
		Meta:          s.status.Metadata,
		Addr:          s.status.ListenAddr,
		APIEncoding:   s.status.APIEncoding,
		Observability: observabilityStateFromVictoria(victoria, s.status.ID, s.status.SessionID, s.status.Root, session),
		Routes:        s.statusDashboardRoutesLocked(s.status.SessionID),
		Aliases:       s.statusDashboardAliasesLocked(s.status.SessionID),
		Compiling:     s.status.Compiling,
		CompileError:  s.status.CompileError,
	}
	s.mu.RUnlock()
	applySessionStatusToAppStatus(&status, session)
	status.Meta = s.metadataWithRuntimePostgresDatabases(status.Meta, status.AppRoot)
	return status
}

func (s *devSupervisor) listApps(ctx context.Context) ([]map[string]any, error) {
	appID := s.activeAppID()
	if appID == "" {
		return []map[string]any{}, nil
	}
	if s.store == nil {
		status := s.appStatus()
		return []map[string]any{{
			"id":                  status.AppID,
			"name":                firstNonEmpty(s.cfg.Name, status.AppID),
			"app_root":            status.AppRoot,
			"session_id":          status.SessionID,
			"offline":             !status.Running,
			"sessionStatus":       status.SessionStatus,
			"sessionStatusReason": status.SessionStatusReason,
			"compileError":        status.CompileError,
		}}, nil
	}
	app, err := s.store.GetApp(ctx, appID)
	if err != nil {
		status := s.appStatus()
		return []map[string]any{{
			"id":                  status.AppID,
			"name":                firstNonEmpty(s.cfg.Name, status.AppID),
			"app_root":            status.AppRoot,
			"session_id":          status.SessionID,
			"offline":             !status.Running,
			"sessionStatus":       status.SessionStatus,
			"sessionStatusReason": status.SessionStatusReason,
			"compileError":        status.CompileError,
		}}, nil
	}
	var session *localagent.Session
	if current := s.currentAgentSession(); current != nil {
		copy := *current
		session = &copy
	}
	applySessionStatusToAppRecord(&app, session)
	return []map[string]any{{
		"id":                  app.ID,
		"name":                app.Name,
		"app_root":            app.Root,
		"session_id":          app.SessionID,
		"offline":             !app.Running,
		"sessionStatus":       app.SessionStatus,
		"sessionStatusReason": app.SessionStatusReason,
		"compileError":        app.CompileError,
	}}, nil
}

func (s *devSupervisor) statusFor(ctx context.Context, appID string) (devdash.AppStatus, error) {
	if appID == "" {
		appID = s.activeAppID()
	}
	if s.store == nil {
		status := s.appStatus()
		if appID == "" || appID == status.AppID || appID == status.SessionID || appID == status.RuntimeAppID {
			return status, nil
		}
		return devdash.AppStatus{}, sql.ErrNoRows
	}
	app, err := s.store.GetApp(ctx, appID)
	if err != nil {
		app, err = s.store.GetAppSession(ctx, appID)
		if err != nil {
			return devdash.AppStatus{}, err
		}
	}
	routeID := firstNonEmpty(app.RouteID, app.ID)
	s.mu.RLock()
	routes := s.statusDashboardRoutesLocked(app.SessionID)
	aliases := s.statusDashboardAliasesLocked(app.SessionID)
	var session *localagent.Session
	var victoria dashboardVictoria
	if s.agentSession != nil {
		copy := *s.agentSession
		session = &copy
	}
	victoria = s.victoria
	s.mu.RUnlock()
	status := devdash.AppStatus{
		Running:       app.Running,
		AppID:         routeID,
		BaseAppID:     app.BaseAppID,
		RuntimeAppID:  app.RuntimeAppID,
		SessionID:     app.SessionID,
		AppRoot:       app.Root,
		PID:           app.PID,
		Meta:          app.Metadata,
		Addr:          app.ListenAddr,
		APIEncoding:   app.APIEncoding,
		Observability: observabilityStateFromVictoria(victoria, routeID, app.SessionID, app.Root, session),
		Routes:        routes,
		Aliases:       aliases,
		Compiling:     app.Compiling,
		CompileError:  app.CompileError,
	}
	applySessionStatusToAppStatus(&status, session)
	status.Meta = s.metadataWithRuntimePostgresDatabases(status.Meta, status.AppRoot)
	return status, nil
}

type dashboardPostgresDatabase struct {
	Name    string                    `json:"name"`
	Source  string                    `json:"source,omitempty"`
	Schemas []dashboardPostgresSchema `json:"schemas,omitempty"`
}

type dashboardPostgresSchema struct {
	Service string `json:"service"`
	Schema  string `json:"schema"`
}

func (s *devSupervisor) metadataWithRuntimePostgresDatabases(metadata json.RawMessage, appRoot string) json.RawMessage {
	if s == nil {
		return metadata
	}
	root := s.root
	if s.worktreeRootPaths != nil {
		root = s.worktreeRootPaths.AppRoot
	}
	if appRoot != root && appRoot != s.root {
		return metadata
	}
	s.mu.RLock()
	database := s.postgresMetadata
	s.mu.RUnlock()
	if database == nil {
		return metadata
	}
	return metadataWithPostgresDatabases(metadata, []dashboardPostgresDatabase{*database})
}

func metadataWithPostgresDatabases(metadata json.RawMessage, databases []dashboardPostgresDatabase) json.RawMessage {
	if len(databases) == 0 {
		return metadata
	}
	payload := map[string]any{}
	if len(metadata) > 0 {
		if err := json.Unmarshal(metadata, &payload); err != nil {
			return metadata
		}
	}
	payload["sql_databases"] = databases
	data, err := json.Marshal(payload)
	if err != nil {
		return metadata
	}
	return data
}

// statusDashboardRoutesLocked requires s.mu to be held.
func (s *devSupervisor) statusDashboardRoutesLocked(sessionID string) map[string]string {
	if s == nil {
		return nil
	}
	if s.agentSession != nil {
		currentSessionID := strings.TrimSpace(s.agentSession.SessionID)
		if sessionID == "" || sessionID == currentSessionID {
			if routes := visibleDashboardRoutesFromAgent(s.agentSession.RouteManifest.URLs()); len(routes) > 0 {
				return routes
			}
		}
	}
	return nil
}

// statusDashboardAliasesLocked requires s.mu to be held.
func (s *devSupervisor) statusDashboardAliasesLocked(sessionID string) map[string]string {
	if s == nil || s.agentSession == nil {
		return nil
	}
	currentSessionID := strings.TrimSpace(s.agentSession.SessionID)
	if sessionID != "" && sessionID != currentSessionID {
		return nil
	}
	return visibleDashboardRoutesFromAgent(s.agentSession.Aliases)
}

func randomToken() (string, error) {
	var buf [16]byte
	if _, err := rand.Read(buf[:]); err != nil {
		return "", err
	}
	return hex.EncodeToString(buf[:]), nil
}

// ensureAssistantTokenKey creates or validates the supervisor-owned stable
// assistant sealing key. The generated key is hex-encoded text containing
// exactly 32 bytes of entropy. Invalid existing material fails closed with an
// error so the caller cannot start an app child with an ambiguous key.
func ensureAssistantTokenKey(stateRoot string) (string, error) {
	stateRoot = strings.TrimSpace(stateRoot)
	if stateRoot == "" {
		return "", errors.New("assistant token key state root is required")
	}
	if err := os.MkdirAll(stateRoot, 0o700); err != nil {
		return "", fmt.Errorf("assistant token key state root: %w", err)
	}
	if info, err := os.Lstat(stateRoot); err != nil || info.Mode()&os.ModeSymlink != 0 || !info.IsDir() {
		return "", errors.New("assistant token key state root is not a private directory")
	} else if err := os.Chmod(stateRoot, 0o700); err != nil {
		return "", fmt.Errorf("protect assistant token key state root: %w", err)
	}
	path := filepath.Join(stateRoot, "token-key")
	if info, err := os.Lstat(path); err == nil {
		if info.Mode()&os.ModeSymlink != 0 || !info.Mode().IsRegular() || info.Mode().Perm()&0o077 != 0 {
			return "", errors.New("assistant token key file is not a private regular file")
		}
		data, err := os.ReadFile(path)
		if err != nil {
			return "", fmt.Errorf("read assistant token key: %w", err)
		}
		if len(data) == 32 && utf8.Valid(data) && strings.TrimSpace(string(data)) == string(data) {
			return path, nil
		}
		key, err := hex.DecodeString(strings.TrimSpace(string(data)))
		if err != nil || len(key) != 32 {
			return "", errors.New("assistant token key file contains invalid key material")
		}
		return path, nil
	} else if !errors.Is(err, os.ErrNotExist) {
		return "", fmt.Errorf("inspect assistant token key: %w", err)
	}

	var key [32]byte
	if _, err := rand.Read(key[:]); err != nil {
		return "", fmt.Errorf("generate assistant token key: %w", err)
	}
	file, err := os.OpenFile(path, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0o600)
	if err != nil {
		if errors.Is(err, os.ErrExist) {
			return ensureAssistantTokenKey(stateRoot)
		}
		return "", fmt.Errorf("create assistant token key: %w", err)
	}
	data := []byte(hex.EncodeToString(key[:]))
	remove := true
	defer func() {
		_ = file.Close()
		if remove {
			_ = os.Remove(path)
		}
	}()
	if _, err := file.Write(data); err != nil {
		return "", fmt.Errorf("write assistant token key: %w", err)
	}
	if err := file.Sync(); err != nil {
		return "", fmt.Errorf("sync assistant token key: %w", err)
	}
	if err := file.Close(); err != nil {
		return "", fmt.Errorf("close assistant token key: %w", err)
	}
	remove = false
	return path, nil
}

func (s *devSupervisor) updateAgentSession(ctx context.Context, status, appPID string) {
	if s == nil || s.agent == nil {
		return
	}
	session := s.currentAgentSession()
	if session == nil {
		return
	}
	updated, err := s.agent.Register(ctx, localagent.RegisterRequest{
		BaseAppID:     s.activeAppID(),
		Environment:   firstNonEmpty(session.Environment, s.env.Name),
		AppRoot:       s.root,
		SessionID:     session.SessionID,
		Branch:        session.Branch,
		Status:        status,
		OwnerPID:      os.Getpid(),
		AppPID:        appPID,
		Processes:     s.sessionProcessesFor(session, appPID),
		Backends:      session.Backends,
		RouteManifest: session.RouteManifest,
		ReportToken:   s.reportToken,
	})
	if err != nil {
		slog.Warn("failed to update scenery agent session", "err", err)
		return
	}
	s.storeAgentSession(&updated)
}

func (s *devSupervisor) sessionProcessesFor(session *localagent.Session, appPID string) map[string]localagent.Process {
	if s == nil || session == nil {
		return nil
	}
	processes := copySessionProcesses(session.Processes)
	s.mu.RLock()
	frontends := make([]*managedFrontendProcess, 0, len(s.frontends))
	for _, process := range s.frontends {
		frontends = append(frontends, process)
	}
	s.mu.RUnlock()
	for key, process := range frontendSessionProcesses(frontends) {
		processes[key] = process
	}
	for key := range processes {
		if strings.HasPrefix(key, "assistant-") {
			delete(processes, key)
		}
	}
	if pid := atoiPID(appPID); pid > 0 {
		processes[localagent.RouteAPI] = localagent.Process{PID: pid}
	}
	if s.assistants != nil {
		for key, process := range s.assistants.ProcessSnapshot() {
			processes[key] = process
		}
	}
	if len(processes) == 0 {
		return nil
	}
	return processes
}

func (s *devSupervisor) currentPID() string {
	if s == nil {
		return ""
	}
	s.mu.RLock()
	defer s.mu.RUnlock()
	if s.current == nil {
		return ""
	}
	return s.current.pid
}

func copySessionProcesses(values map[string]localagent.Process) map[string]localagent.Process {
	if len(values) == 0 {
		return map[string]localagent.Process{}
	}
	copied := make(map[string]localagent.Process, len(values))
	for key, value := range values {
		if strings.TrimSpace(key) == "" || value.PID <= 0 {
			continue
		}
		copied[key] = value
	}
	return copied
}

func portAvailable(addr string) error {
	return netprobe.BindFree(addr)
}
